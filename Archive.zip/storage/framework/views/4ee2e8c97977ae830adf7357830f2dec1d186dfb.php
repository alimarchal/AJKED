<?php $__env->startSection('title'); ?>
    <?php echo e(config('app.name')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customHeaderScripts'); ?>
    <!-- Custom styles for this page -->
    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet"/>
    <style>
        .vertical-header {
            writing-mode: vertical-rl;
            transform: rotate(180deg);
            text-align: left;
            margin: auto;
        }

        @media  print {
            @page  {
                size: auto !important;

            }

            table.table-bordered > thead > tr > th {
                border: 1px solid black !important;
                color: black !important;;
            }

            table.table-bordered > tbody > tr > td {
                border: 1px solid black !important;;
                color: black !important;;
            }
        }


        table.table-bordered > thead > tr > th {
            border: 1px solid black;
            color: black;
        }

        table.table-bordered > tbody > tr > td {
            border: 1px solid black;
            color: black;
        }


    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form action="<?php echo e(route('report.stockReturn')); ?>" method="get" class="d-print-none">
        <div class="form-row">
            <div class="form-group col-md-4">
                <label for="month">Please Select Month</label>
                <input type="date" class="form-control" id="month" name="month">

            </div>

            <div class="form-group col-md-4">
            </div>


            <div class="form-group col-md-4">
                <button type="submit" class="btn btn-success float-right ml-4">Search</button>
                <button class="btn btn-primary float-right mr-4" onclick="window.print()">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-printer" viewBox="0 0 16 16">
                        <path d="M2.5 8a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1z"/>
                        <path
                            d="M5 1a2 2 0 0 0-2 2v2H2a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h1v1a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-1h1a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-1V3a2 2 0 0 0-2-2H5zM4 3a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2H4V3zm1 5a2 2 0 0 0-2 2v1H2a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v-1a2 2 0 0 0-2-2H5zm7 2v3a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1z"/>
                    </svg>
                    Print
                </button>
            </div>


        </div>
    </form>
    <br>

    <!-- Page Heading -->
    <h4 class="h4 mb-4 text-dark font-weight-bold text-center text-uppercase"> Store Stock Return Electricity Division Muzaffarabad For the month of
        <?php echo e(\Carbon\Carbon::parse($date_from)->format('m/Y')); ?>

    </h4>


    <table class="table table-bordered table-responsive">
        <thead>

        <tr class="text-center">
            <th rowspan="2" style="vertical-align : middle;text-align:center;" >S#</th>
            <th rowspan="2" style="vertical-align : middle;text-align:center;">Name of Item</th>
            <th  rowspan="2" style="vertical-align : middle;text-align:center;">Unit</th>
            <th rowspan="2" style="vertical-align : middle;text-align:center;">Received Material During <?php echo e(\Carbon\Carbon::parse($date_from)->format('m/Y')); ?></th>
            <th colspan="<?php echo e(\App\Models\Division::count()+1); ?>" style="vertical-align : middle;text-align:center;"> Issued</th>
            <th rowspan="2" style="vertical-align : middle;text-align:center;">Closing Balance Ending <?php echo e(\Carbon\Carbon::parse($date_from)->format('m/Y')); ?></th>>
        </tr>
        <tr class="text-center">


            <?php $__currentLoopData = \App\Models\Division::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $div): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th style="white-space: nowrap;vertical-align : middle;text-align:center;"><?php echo $div->short_name; ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <th>Total Issued</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = \App\Models\Product::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                <td style="white-space: nowrap"><?php echo e($product->name); ?></td>
                <td class="text-center"><?php echo e($product->unit); ?></td>
                <td class="text-center">
                    <?php if($received_material->where('product_id', $product->id)->isNotEmpty()): ?>
                        <?php echo e($received_material->where('product_id', $product->id)->first()->quantity); ?>

                    <?php else: ?>
                        0
                    <?php endif; ?>
                </td>
                <?php
                    $horizantal_sum = 0;
                ?>
                <?php $__currentLoopData = \App\Models\Division::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $div): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $found = false;
                    ?>

                    <?php $__currentLoopData = $stock_in_out; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $si): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($div->id == $si->division_id && $si->product_id == $product->id): ?>
                            <td class="text-center"><?php echo e($si->quantity); ?></td>
                            <?php $found = true; $horizantal_sum = $horizantal_sum + $si->quantity ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if(!$found): ?>
                        <td class="text-center">0</td>
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <td class="text-right font-weight-bold"><?php echo e(number_format($horizantal_sum,2)); ?></td>
                <td class="text-right font-weight-bold"><?php echo e(number_format($product->quantity,2)); ?></td>

                <?php
                    $horizantal_sum = 0;
                ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('customFooterScripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js" defer></script>
    <script>
        $(document).ready(function () {
            $('.select2').select2();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ajked/resources/views/report/stockReturn.blade.php ENDPATH**/ ?>