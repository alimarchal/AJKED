<?php $__env->startSection('title'); ?>
    <?php echo e(config('app.name')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customHeaderScripts'); ?>
    <!-- Custom styles for this page -->
    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    


    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Store Items</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <?php if($product->isNotEmpty()): ?>
                    <form action="<?php echo e(route('product.index')); ?>" method="get">
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label for="category_id">Category</label>
                                <select class="form-control select2" id="category_id" name="filter[category_id]" style="width: 100%">
                                    <option value="" selected>None</option>
                                    <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group col-md-4">
                                <label for="unit">Name</label>
                                <select class="form-control select2" id="unit" name="filter[name]" style="width: 100%">
                                    <option value="" selected>None</option>
                                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group col-md-4">
                                <button type="submit" class="btn btn-success float-right ml-4">Search</button>
                                <a href="<?php echo e(route('product.index')); ?>" class="btn btn-outline-danger float-right">Reset</a>
                            </div>


                        </div>
                    </form>
                    <br>
                    <table class="table table-bordered" id="" width="100%" cellspacing="0">
                        <thead>
                        <tr>
                            <th class="text-center">No</th>
                            <th>Category</th>
                            <th>Name</th>
                            <th>Unit</th>
                            <th>Quantity</th>

                            <th class="text-center">Action</th>

                        </tr>
                        </thead>

                        <tbody>
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $si): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($si->category->name); ?></td>
                                <td><?php echo e($si->name); ?></td>
                                <td><?php echo e($si->unit); ?></td>
                                <td><?php echo e($si->quantity); ?></td>

                                <td >


                                <div class="text-center">
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-success" data-toggle="modal"
                                            data-target="#exampleModal-<?php echo e($loop->iteration); ?>">
                                        Stock In
                                    </button>
                                </div>

                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal-<?php echo e($loop->iteration); ?>" tabindex="-1"
                                         role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Stock In</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>

                                                <form method="post" action="<?php echo e(route('stockInOut.store')); ?>"
                                                      enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">

                                                        <input type="hidden" name="product_id" value="<?php echo e($si->id); ?>">
                                                        <input type="hidden" name="type" value="In">

                                                        <div class="form-row">
                                                            <div class="form-group col-md-12">
                                                                <label for="supplier_id">Supplier</label>
                                                                <select class="form-control" id="supplier_id"
                                                                        name="supplier_id" required>
                                                                    <option value="">None</option>
                                                                    <?php $__currentLoopData = \App\Models\Supplier::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($item->id); ?>">(<?php echo e($item->type); ?>

                                                                            Category: <?php echo e($item->category); ?>)
                                                                            - <?php echo e($item->description); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>


                                                            <div class="form-group col-md-6">
                                                                <label for="po_no">PO/Indent No</label>
                                                                <input type="text" name="po_no"
                                                                       max="<?php echo e(date('Y-m-d')); ?>" required
                                                                       id="po_no"
                                                                       class="form-control">
                                                            </div>


                                                            <div class="form-group col-md-6">
                                                                <label for="po_date">PO/Indent Date</label>
                                                                <input type="date" name="po_date"
                                                                       max="<?php echo e(date('Y-m-d')); ?>" required
                                                                       id="po_date"
                                                                       class="form-control">
                                                            </div>


                                                            <div class="form-group col-md-6">
                                                                <label for="receiving_po_date">Receiving
                                                                    Date</label>
                                                                <input type="date" name="receiving_po_date"
                                                                       max="<?php echo e(date('Y-m-d')); ?>" required
                                                                       id="receiving_po_date"
                                                                       class="form-control">
                                                            </div>

                                                            <div class="form-group col-md-6">
                                                                <label for="quantity">Quantity:</label>
                                                                <input type="number" placeholder="0" min="0"
                                                                       max="100000000" required step="0.01"
                                                                       name="quantity" id="quantity"
                                                                       class="form-control">
                                                            </div>


                                                            <div class="form-group col-md-12">
                                                                <label for="description">Description</label>
                                                                <textarea class="form-control" id="description"
                                                                          name="description" rows="3"></textarea>
                                                            </div>


                                                            <div class="form-group col-md-12">
                                                                <label for="attachment_path">Attachment (If Any)</label>
                                                                <input type="file" name="attachment_path_1"
                                                                       id="attachment_path" class="form-control-file">
                                                            </div>


                                                        </div>


                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                                data-dismiss="modal">Cancel
                                                        </button>
                                                        <button type="submit" class="btn btn-success">Save Changes
                                                        </button>
                                                    </div>


                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('customFooterScripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js" defer></script>
    <script>
        $(document).ready(function () {
            $('.select2').select2();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ajked/resources/views/product/index.blade.php ENDPATH**/ ?>