<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion d-print-none" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('dashboard')); ?>">
        <div class="sidebar-brand-icon ">
            <!-- rotate-n-15 -->
            <img src="<?php echo e(Storage::url('logo.png')); ?>" alt="<?php echo e(Storage::url('logo.png')); ?>" style="height: 70px;">

        </div>
        <div class="sidebar-brand-text mx-3">AJKED</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item <?php if(request()->routeIs('dashboard')): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Interface
    </div>

    <!-- Nav Item - Pages Collapse Menu -->

    <li class="nav-item <?php if(request()->routeIs('product.*')): ?> active <?php endif; ?>">
        <a class="nav-link collapsed " href="#" data-toggle="collapse" data-target="#collapseFour"
           aria-expanded="true" aria-controls="collapseFour">
            <i class="fas fa-fw fa-warehouse"></i>
            <span>Store Items</span>
        </a>
        <div id="collapseFour" class="collapse  <?php if(request()->routeIs('product.*')): ?> show <?php endif; ?>" aria-labelledby="headingFour" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                
                <a class="collapse-item <?php if(request()->routeIs('product.create')): ?> active <?php endif; ?>" href="<?php echo e(route('product.create')); ?>">Create Store Items</a>
                <a class="collapse-item <?php if(request()->routeIs('product.index')): ?> active <?php endif; ?>" href="<?php echo e(route('product.index')); ?>">Show All / Stock In</a>
                <a class="collapse-item <?php if(request()->routeIs('product.stockOut')): ?> active <?php endif; ?>" href="<?php echo e(route('product.stockOut')); ?>">Stock Out</a>
                        <h6 class="collapse-header">Stock In/Out Status:</h6>
                <a class="collapse-item <?php if(request()->routeIs('product.stockInRegister')): ?> active <?php endif; ?>" href="<?php echo e(route('product.stockInRegister')); ?>">Stock In Details</a>
                <a class="collapse-item <?php if(request()->routeIs('product.stockOutRegister')): ?> active <?php endif; ?>" href="<?php echo e(route('product.stockOutRegister')); ?>">Stock Out Details</a>
            </div>
        </div>
    </li>


    <li class="nav-item <?php if(request()->routeIs('report.*')): ?> active <?php endif; ?>">
        <a class="nav-link collapsed " href="#" data-toggle="collapse" data-target="#collapseReport"
           aria-expanded="true" aria-controls="collapseReport">
            <i class="fas fa-fw fa-clipboard-list"></i>
            <span>Reporting</span>
        </a>
        <div id="collapseReport" class="collapse  <?php if(request()->routeIs('report.*')): ?> show <?php endif; ?>" aria-labelledby="headingReport" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                
                <a class="collapse-item <?php if(request()->routeIs('product.create')): ?> active <?php endif; ?>" href="<?php echo e(route('report.stockReturn')); ?>">Stock Return</a>
            </div>
        </div>
    </li>


    <li class="nav-item <?php if(request()->routeIs('supplier.*')): ?> active <?php endif; ?>">
        <a class="nav-link collapsed " href="#" data-toggle="collapse" data-target="#collapseTwo"
           aria-expanded="true" aria-controls="collapseTwo">
            <i class="fas fa-fw fa-users"></i>
            <span>Suppliers</span>
        </a>
        <div id="collapseTwo" class="collapse  <?php if(request()->routeIs('supplier.*')): ?> show <?php endif; ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">

                <a class="collapse-item <?php if(request()->routeIs('supplier.create')): ?> active <?php endif; ?>" href="<?php echo e(route('supplier.create')); ?>">Create Supplier</a>
                <a class="collapse-item <?php if(request()->routeIs('supplier.index')): ?> active <?php endif; ?>" href="<?php echo e(route('supplier.index')); ?>">Show All</a>
            </div>
        </div>
    </li>


    <li class="nav-item <?php if(request()->routeIs('division.*')): ?> active <?php endif; ?>">
        <a class="nav-link collapsed " href="#" data-toggle="collapse" data-target="#collapseThree"
           aria-expanded="true" aria-controls="collapseThree">
            <i class="fas fa-fw fa-building"></i>
            <span>Divisions</span>
        </a>
        <div id="collapseThree" class="collapse  <?php if(request()->routeIs('division.*')): ?> show <?php endif; ?>" aria-labelledby="headingThree" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                
                <a class="collapse-item <?php if(request()->routeIs('division.create')): ?> active <?php endif; ?>" href="<?php echo e(route('division.create')); ?>">Create Division</a>
                <a class="collapse-item <?php if(request()->routeIs('division.index')): ?> active <?php endif; ?>" href="<?php echo e(route('division.index')); ?>">Show All</a>
            </div>
        </div>
    </li>

    <li class="nav-item <?php if(request()->routeIs('category.*')): ?> active <?php endif; ?>">
        <a class="nav-link collapsed " href="#" data-toggle="collapse" data-target="#collapseFive"
           aria-expanded="true" aria-controls="collapseFive">
            <i class="fas fa-fw fa-list-alt"></i>
            <span>Category</span>
        </a>
        <div id="collapseFive" class="collapse  <?php if(request()->routeIs('category.*')): ?> show <?php endif; ?>" aria-labelledby="headingFive" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                
                <a class="collapse-item <?php if(request()->routeIs('category.create')): ?> active <?php endif; ?>" href="<?php echo e(route('category.create')); ?>">Create Category</a>
                <a class="collapse-item <?php if(request()->routeIs('category.index')): ?> active <?php endif; ?>" href="<?php echo e(route('category.index')); ?>">Show All</a>
            </div>
        </div>
    </li>

















    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>



</ul>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ajked/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>