<?php $__env->startSection('title'); ?>
    <?php echo e(config('app.name')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customHeaderScripts'); ?>
    <!-- Custom styles for this page -->
    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet"/>


    <link rel="stylesheet" href="<?php echo e(url('css/daterangepicker.min.css')); ?>">
    <script src="<?php echo e(url('js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/knockout-3.5.1.js')); ?>" defer></script>
    <script src="<?php echo e(url('js/daterangepicker.min.js')); ?>" defer></script>

    <style>
        .vertical-header {
            writing-mode: vertical-rl;
            transform: rotate(180deg);
            text-align: left;
            margin: auto;
        }

        @media  print {
            @page  {
                size: auto !important
            }
        }


        table.table-bordered > thead > tr > th {
            border: 1px solid black;
            color: black;
        }

        table.table-bordered > tbody > tr > td {
            border: 1px solid black;
            color: black;
        }


    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form action="<?php echo e(route('product.stockOutRegister')); ?>" method="get" class="d-print-none">
        <div class="form-row">


            <div class="form-group col-md-4">
                <label for="division_id">Division</label>
                <select class="form-control select2" id="division_id" name="division_id" style="width: 100%;">
                    <option value="" selected>Please select division</option>
                    <?php $__currentLoopData = \App\Models\Division::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group col-md-4">
                <label for="month">Please Select Month</label>
                
                <input type="search" name="date_range" id="date_range" class="form-control">
            </div>






            <div class="form-group col-md-4">
                <button type="submit" class="btn btn-success float-right ml-4">Search</button>
                <button class="btn btn-primary float-right mr-4" onclick="window.print()">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-printer" viewBox="0 0 16 16">
                        <path d="M2.5 8a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1z"/>
                        <path
                            d="M5 1a2 2 0 0 0-2 2v2H2a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h1v1a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-1h1a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-1V3a2 2 0 0 0-2-2H5zM4 3a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2H4V3zm1 5a2 2 0 0 0-2 2v1H2a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v-1a2 2 0 0 0-2-2H5zm7 2v3a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1z"/>
                    </svg>
                    Print
                </button>
            </div>


        </div>
    </form>
    <br>

    <!-- Page Heading -->
    <h4 class="h4 mb-4 text-dark font-weight-bold text-center"> Store Stock Register Store Division Electricity Muzaffarabad (Issued) <br>
        Month: <?php echo e(\Carbon\Carbon::parse($date_from)->format('M/Y')); ?> </h4>

    <table class="table table-sm table-bordered table-responsive">
        <thead style="white-space: nowrap">
        <tr>
            <th></th>
            <th></th>
            <th></th>

            <?php $__currentLoopData = \App\Models\Product::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th scope="col">
                    <div class="vertical-header"><?php echo e($product->unit); ?></div>
                </th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <th scope="col">
            </th>
        </tr>
        <tr>
            <th scope="col" style="writing-mode: vertical-rl; transform: rotate(180deg); text-align: center; vertical-align: middle;">Indent No.</th>
            <th scope="col" style="margin: auto; vertical-align: middle; text-align: center; width: 50px!important;;">Date</th>
            <th scope="col" style="margin: auto; vertical-align: middle; text-align: center; width: 100px!important;;">Particulars</th>

            <?php $__currentLoopData = \App\Models\Product::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th scope="col">
                    <div class="vertical-header"><?php echo e($product->name); ?></div>
                </th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <th scope="col">
                <div class="vertical-header">Total</div>
            </th>
        </tr>

        <tr>
            <th scope="col"></th>
            <th scope="col"></th>
            <th scope="col"></th>

            <?php $__currentLoopData = \App\Models\Product::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th scope="col" style="text-align: center;"><?php echo e($loop->iteration); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <th scope="col" style="text-align: center;"></th>
        </tr>
        </thead>
        <tbody>
        <?php $horizantal_sum = 0; $vertical_sum = 0; ?>

        
        
        
        
        
        

        
        
        
        
        
        
        
        
        
        
        
        


        <?php $horizantal_sum = 0; $horizantal_sum_grand = 0; $vertical_sum = 0; ?>

        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="white-space: nowrap;"><?php echo e($key); ?></td>
                <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td style="white-space: nowrap;"><?php echo e(\Carbon\Carbon::parse($k)->format('d-m-Y')); ?></td>
                    <?php $__currentLoopData = $v; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td style="white-space: nowrap;"><?php echo e($i); ?></td>
                        <?php $__currentLoopData = \App\Models\Product::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $found = false; ?>
                            <?php $__currentLoopData = $x; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($b->product_id === $product->id): ?>
                                    <td class="text-center"><?php echo e($b->quantity); ?></td>
                                    <?php
                                        $found = true;
                                        $horizantal_sum = $horizantal_sum +$b->quantity;
                                    ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!$found): ?>
                                <td class="text-center">-</td>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td class="text-right font-weight-bold text-danger"><?php echo e(number_format($horizantal_sum,2)); ?></td>
                        <?php $horizantal_sum = 0; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        
        
        
        

        
        
        
        
        
        
        
        
        
        
        
        

        
        
        
        
        
        
        


        <tr class="font-weight-bold">
            <td colspan="3" class="text-center">Total</td>

            <?php $__currentLoopData = \App\Models\Product::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td class="text-center text-danger">
                    <?php if($stock_in_out->where('product_id',$product->id)->sum('quantity') == 0): ?>
                        -
                    <?php else: ?>
                        <?php echo e(number_format($stock_in_out->where('product_id',$product->id)->sum('quantity'),2)); ?>

                        <?php $horizantal_sum_grand = $horizantal_sum_grand + $stock_in_out->where('product_id',$product->id)->sum('quantity'); ?>
                    <?php endif; ?>
                </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <td class="text-center text-danger">
                <?php echo e(number_format($horizantal_sum_grand,2)); ?>

            </td>

        </tr>


        </tbody>
    </table>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('customFooterScripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js" defer></script>
    <script>
        $(document).ready(function () {
            $('.select2').select2();
        });
    </script>

    <script>
        $(document).ready(function () {
            $("#date_range").daterangepicker({
                minDate: moment().subtract(10, 'years'),
                orientation: 'left',
                callback: function (startDate, endDate, period) {
                    $(this).val(startDate.format('L') + ' – ' + endDate.format('L'));
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ajked/resources/views/product/stockInRegister.blade.php ENDPATH**/ ?>