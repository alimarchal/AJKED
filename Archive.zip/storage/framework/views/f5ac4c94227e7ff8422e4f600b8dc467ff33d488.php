<?php $__env->startSection('title'); ?>
    <?php echo e(config('app.name')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customHeaderScripts'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <h4 class="h4 mb-4 text-gray-800">Create Store Item</h4>

    <form method="post" action="<?php echo e(route('product.stockOutStore')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-row">
            <div class="form-group col-md-12">
                <label for="division_id" class="text-danger">Division</label>
                <select class="form-control select2" id="division_id" name="division_id" required style="width: 100%;">
                    <option value="" selected>Please select division</option>
                    <?php $__currentLoopData = \App\Models\Division::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>


            <input type="hidden" name="type" value="Out">

            <div class="form-group col-md-6">
                <label for="indent_no">Indent No</label>
                <input type="text" name="indent_no" required id="indent_no" class="form-control">
            </div>


            <div class="form-group col-md-6">
                <label for="indent_date">Stock Out Date</label>
                <input type="date" name="indent_date" max="<?php echo e(date('Y-m-d')); ?>" required id="indent_date" class="form-control">
            </div>
        </div>

        <div class="row">
            <div class="form-group col-md-6">
                <label for="product_id" class="text-danger">Store Item</label>
                <select class="form-control " id="product_id" name="product_id[]" required style="width: 100%;">
                    <option value="" selected>Please select quantity</option>
                    <?php $__currentLoopData = $product->where('quantity','>',0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>">(<?php echo e($item->category->name); ?>) <?php echo e($item->name); ?> | Quantity: (<?php echo e($item->quantity); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group col-md-6">
                <label for="quantity">Quantity</label>
                <input type="number" min="1" max="100000000" required step="0.01" name="quantity[]" id="quantity" class="form-control">
            </div>
        </div>

        <div class="myrow">

        </div>




        <div class="row">
            <div class="col-md-12">
                <a id="add_more" type="" class="btn btn-success float-right"> Add More</a>
            </div>
        </div>





        <button type="submit" class="btn btn-primary">Confirm</button>
    </form>


    <div class="newqual" style="display: none">

        <div class="row">
            <div class="cross col-md-12">
                <a href="javascript:(0);" class="btn btn-danger float-right">Delete</a>
            </div>
            <div class="form-group col-md-6">
                <label for="product_id" class="text-danger">Store Item</label>
                <select class="form-control" id="product_id" name="product_id[]" required style="width: 100%;">
                    <option value="" selected>Please select quantity</option>
                    <?php $__currentLoopData = $product->where('quantity','>',0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>">(<?php echo e($item->category->name); ?>) <?php echo e($item->name); ?> | Quantity: (<?php echo e($item->quantity); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group col-md-6">
                <label for="quantity">Quantity</label>
                <input type="number" min="1" max="100000000" required step="0.01" name="quantity[]" id="quantity" class="form-control">
            </div>
        </div>
    </div>


<?php $__env->startSection('customFooterScripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js" defer></script>
    <script>
        $(document).ready(function () {
            var traing_count = 1;
            $('.select2').select2();


            $("body").delegate("#add_more", "click", function () {
                $('.myrow').append($('.newqual').html());
                $("form .select2").select2();
            });
            $("body").delegate("#add_more_integrent", "click", function () {

                var training_html = $('.newqual').html();

                training_html = training_html.replaceAll('xcount_replaceable',traing_count);
                traing_count++;


                $('.myrow').append(training_html);
            });
            $("body").delegate(".cross a", "click", function () {
                $(this).closest(".row").remove();
                return false;
            });

        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ajked/resources/views/product/stockOut.blade.php ENDPATH**/ ?>