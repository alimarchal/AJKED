<?php $__env->startSection('title'); ?>
    <?php echo e(config('app.name')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customHeaderScripts'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <h4 class="h4 mb-4 text-gray-800">Create Vendors/Suppliers</h4>

    <form method="post" action="<?php echo e(route('supplier.update',$supplier->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="type">Type</label>
                <select class="form-control select2" id="type" name="type[]" multiple required>
                    <option value="">None</option>
                    <?php $__currentLoopData = \App\Models\Supplier::supplier_list(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item); ?>" <?php if($item == in_array($item,$type)): ?> selected <?php endif; ?>><?php echo e($item); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group col-md-6">
                <label for="category">Category</label>
                <?php echo e($supplier->category); ?>

                <select class="form-control select2" id="category" name="category" required>
                    <?php $__currentLoopData = \App\Models\Supplier::distinct('category')->pluck('category'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sup); ?>" <?php if($sup == $supplier->category): ?>  selected <?php endif; ?> ><?php echo e($sup); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label for="description">Description:</label>
            <textarea class="form-control" rows="5" id="description" name="description" required><?php echo e($supplier->description); ?></textarea>
        </div>

        <div class="form-group">
            <label for="status">Status (Active/Non-Active</label>
            <select class="form-control" id="status" name="status" required>
                <option value="">None</option>
                <option value="Active" <?php if($supplier->status == "Active"): ?> selected <?php endif; ?>>Active</option>
                <option value="NonActive" <?php if($supplier->status == "NonActive"): ?> selected <?php endif; ?>>Non Active</option>
            </select>
        </div>


        <button type="submit" class="btn btn-primary">Update</button>
    </form>


<?php $__env->startSection('customFooterScripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js" defer></script>
    <script>
        $(document).ready(function () {
            $('.select2').select2();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ajked/resources/views/suppliers/edit.blade.php ENDPATH**/ ?>