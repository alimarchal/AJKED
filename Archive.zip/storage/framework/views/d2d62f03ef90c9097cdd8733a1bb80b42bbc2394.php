



<img src="<?php echo e(Storage::url('logo.png')); ?>" class="h-16 w-auto"/>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ajked/resources/views/vendor/jetstream/components/application-mark.blade.php ENDPATH**/ ?>